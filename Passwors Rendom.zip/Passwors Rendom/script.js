const generateBtn = document.getElementById("generateBtn");
const passwordField = document.getElementById("passwordField");
const modal = document.getElementById("myModal");
const closeModal = document.getElementById("closeModal");
const modalContent = document.getElementById("modalContent");

generateBtn.addEventListener("click", function () {
  const allowed = {
    uppers: "ABCDEFGHIJKLMNOPQRSTUVWYZ",
    lowers: "abcdefghijklmnopqrstuvwxyz",
    numbers: "1234567890",
    symbols: "!@#$'&",
  };

  const randomPassword = (str) =>
    str.charAt(Math.floor(Math.random() * str.length));

  const generatePassword = (length = 12) => {
    let password = "";
    password += randomPassword(allowed.uppers);
    password += randomPassword(allowed.lowers);
    password += randomPassword(allowed.numbers);
    password += randomPassword(allowed.symbols);

    for (let i = password.length; i < length; i++) {
      password += randomPassword(Object.values(allowed).join(""));
    }
    return password;
  };

  // Generate the password
  const password = generatePassword();
  passwordField.value = password;

  // Show modal with password details
  modalContent.innerHTML = `
    <p><strong>Password:</strong> ${password}</p>
    <p>This password is randomly generated and will be cleared in 1 minute.</p>
  `;
  modal.style.display = "block";

  // Automatically clear the password after 1 minute
  setTimeout(() => {
    passwordField.value = "";
  }, 60000);
});

// Close the modal when the 'x' is clicked
closeModal.addEventListener("click", () => {
  modal.style.display = "none";
});

// Close the modal when clicking outside of it
window.addEventListener("click", (event) => {
  if (event.target == modal) {
    modal.style.display = "none";
  }
});

